# -*- coding: utf-8 -*-
import scrapy

from test2.items import Test2Item

class TSpiderSpider(scrapy.Spider):
    name = 't_spider'
    allowed_domains = ['movie.douban.com']
    start_urls = ['https://movie.douban.com/top250']

    def parse(self, response):
        '''
            作用：
            1.解析返回的网页数据，提取结构化数据（生成item）
            2.生成访问下一页数据的url
            '''
        # with open("teacher.html",'w',encoding='utf-8') as f:
        #     f.write(response.text)

        # print(response.text)


        items = []  # 存放老师的信息列表
        for each in response.xpath('//ol[@class="grid_view"]/li'):
            # 将我们得到的数据封装成一个Test1Item对象
            item = Test2Item()
            movie_name = each.xpath('//div[@class="hd"]/a/span[1]').extract()
            score = each.xpath('//div[@class="bd"]/div["star"]/span[2]/text()').extract()
            num_person = each.xpath('//div[@class="bd"]/div["star"]/span[4]/text()').extract()

            item['movie_name'] = movie_name[0]
            item['score'] = score[0]
            item['num_person'] = num_person[0]

            items.append(item)
        print(items)
            # 返回数据，先不设置pipeline

        return items

# -*- coding: utf-8 -*-
import scrapy

from douban.items import DoubanItem
class MovieSpider(scrapy.Spider):
    name = 'movie'
    allowed_domains = ['movie.douban.com/top250']
    start_urls = ['http://movie.douban.com/top250/?start={}&filter='.format(page*25) for page in range(0,10)]


    def parse(self, response):
        items = []

        movie_list = response.xpath('//ol[@class="grid_view"]/li')

        for info in movie_list:
            print(info.extract())
            print('-'*100)
            douban_item = DoubanItem()
            douban_item['movie_id'] = info.xpath(".//div[@class='item']//em/text()").extract_first("")

            douban_item['movie_name'] = info.xpath('.//div[@class="hd"]/a/span[1]/text()').extract()[0]
            counts = info.xpath(".//div[@class='bd']/p[1]/text()").extract()  #这里会匹配到个对象 循环一下 后面会把前面覆盖掉。
            for count_ in counts:
                count_s = "".join(count_.split())
                douban_item['movie_introduce'] = count_s
            print(counts)
            douban_item['movie_star'] = info.xpath(".//div[@class='star']/span[2]/text()").extract_first("")
            douban_item['movie_evaluate'] = info.xpath(".//div[@class='star']/span[4]/text()").extract_first("")
            douban_item['movie_describe'] = info.xpath(".//div[@class='bd']/p/span[1]/text()").extract_first("")
            print(douban_item)
            # return douban_item
# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
from scrapy.exporters import CsvItemExporter
import pymysql

class DoubanPipeline(object):
    def process_item(self, item, spider):
        return item

class CsvDoubanPipeline(object):
    def __init__(self):
        #创建接收文件，初始化属性
        self.file = open("movie.csv",'ab')
        # fields_to_export 里放入Items字段列表
        self.exporter = CsvItemExporter(self.file,fields_to_export=['moive_id','movie_name',"movie_introduce",'movie_star',"movie_evaluate","movie_describe"])
        self.exporter.start_exporting()

    def process_item(self,item,spider):
        self.exporter.export_item(item)
        return item


    def spider_close(self,spider):
        self.exporter.finish_exporting()  #结束exporter的exporting
        self.file.close()

class MysqlDoubanPipeline(object):
    def __init__(self):
        # 建立连接
        self.conn = pymysql.connect(host='localhost',user='root',password="123456",database='douban', charset="utf8")  # 有中文要存入数据库的话要加charset='utf8'
        # 创建游标
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        # sql语句
        insert_sql = """
        insert into douban_top250_info(movie_id,movie_name,movie_introduce,movie_star,movie_evaluate,movie_describe) VALUES(%s,%s,%s,%s,%s,%s)
        """
        # 执行插入数据到数据库操作
        self.cursor.execute(insert_sql, (item['movie_id'], item['movie_name'], item['movie_introduce'], item['movie_star'],
                                         item['movie_evaluate'],item['movie_describe']))
        # 提交，不进行提交无法保存到数据库
        self.conn.commit()

    def close_spider(self, spider):
        # 关闭游标和连接
        self.cursor.close()
        self.conn.close()
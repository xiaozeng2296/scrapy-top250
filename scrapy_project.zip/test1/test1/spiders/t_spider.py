# -*- coding: utf-8 -*-
import scrapy
from test1.items import Test1Item


class TSpiderSpider(scrapy.Spider):
    name = 't_spider'
    allowed_domains = ['itcast.cn']
    start_urls = ['http://itcast.cn/channel/teacher.shtml']

    def parse(self, response):
        '''
        作用：
        1.解析返回的网页数据，提取结构化数据（生成item）
        2.生成访问下一页数据的url
        '''
        # with open("teacher.html",'w',encoding='utf-8') as f:
        #     f.write(response.text)
        items = []  #存放老师的信息列表
        for each in response.xpath('//div[@class="maincon"]/ul/li'):
            #将我们得到的数据封装成一个Test1Item对象
            item = Test1Item()
            name = each.xpath('.div[@class="main_bot"]/h2/text()').extract()    #不能在子查询里面再加/了  这样就表示从根目录开始搜索
            # mask_1 = each.xpath('div[@class="main_bot"]/h3/span').extract()
            # mask_2 = each.xpath('div[@class="main_bot"]/h3/span[2]/text()').extract()    #不是所有老师都有两个标签的
            ruzhi_time  = each.xpath('.div[@class="main_mask"]/h3/text()').extract()
            info = each.xpath('.div[@class="main_mask"]/p/text()').extract()
            teacher_pic = each.xpath('.div/img/@src').extract()

            #xpath返回的是一个列表，我们要将他取出来
            item["name"] = name[0]
            # item["mask_1"] = mask_1[0]
            # item["mask_2"] = mask_2[0]
            item["ruzhi_time"] = ruzhi_time[0]
            item["info"] = info[0]
            item["teacher_pic"] = teacher_pic[0]
            items.append(item)
            yield item
            #返回数据，先不设置pipeline
